print("the contents of the text file/n")


text_handler=open("filetext.txt", "r")
reading=text_handler.read()
print(reading)

text_handler.close()


text_handler=open("filetext.txt" , "r")

search_key=input("enter the word you want to search for: ")
find_count=0

for line in text_handler:

	finder=line.lower().find(search_key.lower())
	if finder != -1:
		find_count +=1


print(f"the word {search_key} is found {find_count} times in the text file")


