def is_even(n):

	if (n % 2) == 0:
		print("the given number is an even number")
	else:
		print("the given number is an odd number")

def main():
	number=int(input("enter an integer"))
	is_even(number)
main()