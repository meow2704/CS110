n=int(input("enter a positive number"))
fib1=1
fib2=1

if n==1 or n==2:
	print(f"the {n}th number of the fibonacci series is :1")
else:
	for n in range(3,n+1):
		fib_new=fib1+fib2
		fib1=fib2
		fib2=fib_new
	print(f"the {n}th number in the fibonacci series is {fib_new}")