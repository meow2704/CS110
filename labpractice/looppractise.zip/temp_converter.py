
print("celsius \t fahrenheit")

for celsius in range(0,101,10):
	fahrenheit=(celsius*9/5)+32
	print("{:.2f} \t {:.2f}".format(celsius , fahrenheit))
