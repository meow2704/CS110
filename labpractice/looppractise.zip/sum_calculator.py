
for num in range (0,101):
	total=sum(range(0,101))

print(total)

end_point=int(input("enter the end number"))

for num in range (0,end_point+1):
	total=sum(range(0,end_point+1))
print(total)